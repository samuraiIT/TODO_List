# TODO list backed service

```shell
docker-compose docker-compose.yml up -d
./gradlew clean build
```