package ru.vtb.todo.model

data class ErrorDescription(
    val field: String,
    val error: String
)
