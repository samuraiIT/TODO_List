package ru.vtb.todo.model

data class ErrorResponse(
    val message: String
)