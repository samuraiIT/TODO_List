package ru.vtb.todo.model

import java.util.*

data class ListItem(
    val uid: UUID,
    val text: String
)
