package ru.vtb.todo.exceptions

class ItemAlreadyExistsException(message: String) : RuntimeException(message)
