-- V100 Create Items table
CREATE TABLE items
(
    id   uuid PRIMARY KEY,
    text VARCHAR(255) NOT NULL
)